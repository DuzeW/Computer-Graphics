#include "circle.h"
#define _USE_MATH_DEFINES
#include <GL/glew.h>
#include <math.h>

void Circle::Initialize(){
  const int numPoints = 32;
  GLfloat angleStep = M_PI * 2.0f / (float)numPoints;
  GLfloat kVertices[numPoints * 4];
  GLfloat kColors[numPoints * 4];

  for (int i = 0; i < numPoints; ++i) {
    float angle = i * angleStep;
    float x = cos(angle);
    float y = sin(angle);
    kVertices[i * 4] = x;
    kVertices[i * 4 + 1] = y;
    kVertices[i * 4 + 2] = 0.0f;
    kVertices[i * 4 + 3] = 1.0f;
  }

for (int i = 0; i < numPoints; ++i) {
    kColors[i * 4] = 0.0f;      // Red
    kColors[i * 4 + 1] = 0.0f;  // Green
    kColors[i * 4 + 2] = 2.0f;  // Blue
    kColors[i * 4 + 3] = 1.0f;  // Alpha
}

    glGenVertexArrays(1, &vao_);
    glBindVertexArray(vao_);

    glGenBuffers(1, &vertex_buffer_);
    glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(kVertices), kVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, nullptr);
    glEnableVertexAttribArray(0);

    glGenBuffers(1, &color_buffer_);
    glBindBuffer(GL_ARRAY_BUFFER, color_buffer_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(kColors), kColors, GL_STATIC_DRAW);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, nullptr);
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

Circle::~Circle(){
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glDeleteBuffers(1, &color_buffer_);
    glDeleteBuffers(1, &vertex_buffer_);

    glBindVertexArray(0);
    glDeleteVertexArrays(1, &vao_);
}

void Circle::Draw(const Program &program){

    glUseProgram(program);
    glBindVertexArray(vao_);

    glDrawArrays(GL_LINE_LOOP, 0, 32);

    glBindVertexArray(0);
    glUseProgram(0);


}
